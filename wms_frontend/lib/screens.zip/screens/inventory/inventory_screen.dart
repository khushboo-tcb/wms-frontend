import 'package:flutter/material.dart';
import '../../main.dart';
import '../dashboard/dashboard_screen.dart';
import '../inbound/inbound_screen.dart';

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  // ============================================================
  // LOGOUT
  // ============================================================

  void _logout(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Logout'),
          content: const Text(
            'Are you sure you want to logout?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(dialogContext);

                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LoginScreen(),
                  ),
                  (route) => false,
                );
              },
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // NAVIGATION
  // ============================================================

  void _navigateToModule(
    BuildContext context,
    String title,
  ) {
    // ================= DASHBOARD =================

    if (title == 'Dashboard') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const DashboardScreen(),
        ),
      );
    }

    // ================= INVENTORY =================

    else if (title == 'Inventory') {
      // Already on Inventory
    }

    // ================= INBOUND =================

    else if (title == 'Inbound') {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const InboundScreen(),
        ),
      );
    }

    // ================= OTHER MODULES =================

    else if (title == 'Logout') {
      _logout(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '$title module is not implemented yet.',
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      body: Row(
        children: [

          // =====================================================
          // SIDEBAR
          // =====================================================

          Container(
            width: 235,
            color: const Color(0xFF111827),
            child: Column(
              children: [

                // ================= WMS LOGO =================

                Container(
                  height: 88,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: Row(
                    children: const [
                      Icon(
                        Icons.warehouse,
                        color: Colors.white,
                        size: 32,
                      ),

                      SizedBox(width: 11),

                      Column(
                        mainAxisAlignment:
                            MainAxisAlignment.center,
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            'WMS',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 21,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          Text(
                            'Warehouse Management',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 9,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const Divider(
                  color: Colors.white12,
                ),

                // ================= SIDEBAR MENU =================

                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 14,
                    ),
                    children: [

                      _menuItem(
                        Icons.dashboard_outlined,
                        'Dashboard',
                        false,
                        context,
                      ),

                      _menuItem(
                        Icons.inventory_2_outlined,
                        'Inventory',
                        true,
                        context,
                      ),

                      _menuItem(
                        Icons.download_outlined,
                        'Inbound',
                        false,
                        context,
                      ),

                      _menuItem(
                        Icons.upload_outlined,
                        'Outbound',
                        false,
                        context,
                      ),

                      _menuItem(
                        Icons.warehouse_outlined,
                        'Warehouse',
                        false,
                        context,
                      ),

                      _menuItem(
                        Icons.bar_chart_outlined,
                        'Reports',
                        false,
                        context,
                      ),

                      const SizedBox(height: 10),

                      const Divider(
                        color: Colors.white12,
                      ),

                      const SizedBox(height: 10),

                      _menuItem(
                        Icons.notifications_none,
                        'Notifications',
                        false,
                        context,
                      ),

                      _menuItem(
                        Icons.settings_outlined,
                        'Settings',
                        false,
                        context,
                      ),

                      _menuItem(
                        Icons.person_outline,
                        'Profile',
                        false,
                        context,
                      ),
                    ],
                  ),
                ),

                // ================= LOGOUT =================

                Padding(
                  padding: const EdgeInsets.all(12),
                  child: _menuItem(
                    Icons.logout,
                    'Logout',
                    false,
                    context,
                  ),
                ),
              ],
            ),
          ),

          // =====================================================
          // MAIN AREA
          // =====================================================

          Expanded(
            child: Column(
              children: [

                // =================================================
                // TOP BAR
                // =================================================

                Container(
                  height: 70,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                  ),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(
                      bottom: BorderSide(
                        color: Color(0xFFE5E7EB),
                      ),
                    ),
                  ),
                  child: Row(
                    children: [

                      const Text(
                        'Inventory',
                        style: TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF111827),
                        ),
                      ),

                      const Spacer(),

                      // ================= SEARCH =================

                      Container(
                        width: 270,
                        height: 40,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF8FAFC),
                          borderRadius:
                              BorderRadius.circular(8),
                          border: Border.all(
                            color: const Color(0xFFE5E7EB),
                          ),
                        ),
                        child: TextField(
                          onSubmitted: (value) {
                            if (value.isNotEmpty) {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'Searching for "$value"',
                                  ),
                                ),
                              );
                            }
                          },
                          decoration: const InputDecoration(
                            hintText: 'Search...',
                            prefixIcon: Icon(
                              Icons.search,
                              size: 19,
                            ),
                            border: InputBorder.none,
                            contentPadding:
                                EdgeInsets.only(top: 9),
                          ),
                        ),
                      ),

                      const SizedBox(width: 18),

                      // ================= NOTIFICATION =================

                      Stack(
                        children: [

                          IconButton(
                            onPressed: () {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'You have 5 notifications.',
                                  ),
                                ),
                              );
                            },
                            icon: const Icon(
                              Icons.notifications_none,
                              size: 24,
                            ),
                          ),

                          Positioned(
                            right: 5,
                            top: 4,
                            child: Container(
                              width: 16,
                              height: 16,
                              decoration:
                                  const BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                              ),
                              child: const Center(
                                child: Text(
                                  '5',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight:
                                        FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(width: 8),

                      // ================= PROFILE =================

                      InkWell(
                        borderRadius:
                            BorderRadius.circular(20),
                        onTap: () {
                          ScaffoldMessenger.of(context)
                              .showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Profile clicked.',
                              ),
                            ),
                          );
                        },
                        child: const CircleAvatar(
                          radius: 18,
                          child: Icon(
                            Icons.person,
                            size: 20,
                          ),
                        ),
                      ),

                      const SizedBox(width: 9),

                      const Text(
                        'Administrator',
                        style: TextStyle(
                          color: Color(0xFF374151),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      const SizedBox(width: 12),

                      const Icon(
                        Icons.keyboard_arrow_down,
                        size: 20,
                      ),
                    ],
                  ),
                ),

                // =================================================
                // CONTENT
                // =================================================

                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(26),
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [

                        const Text(
                          'Inventory Management',
                          style: TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF111827),
                          ),
                        ),

                        const SizedBox(height: 5),

                        const Text(
                          'Monitor and manage inventory across warehouses, locations and stock levels.',
                          style: TextStyle(
                            color: Color(0xFF6B7280),
                            fontSize: 13,
                          ),
                        ),

                        const SizedBox(height: 22),

                        // =================================================
                        // KPI CARDS
                        // =================================================

                        Row(
                          children: [

                            Expanded(
                              child: _statCard(
                                title: 'Total Items',
                                value: '1,250',
                                subtitle:
                                    'Items in inventory',
                                icon:
                                    Icons.inventory_2_outlined,
                                iconBackground:
                                    const Color(0xFFE8F0FF),
                                onTap: () {
                                  _showMessage(
                                    context,
                                    'Total Items: 1,250',
                                  );
                                },
                              ),
                            ),

                            const SizedBox(width: 14),

                            Expanded(
                              child: _statCard(
                                title: 'Available Stock',
                                value: '1,120',
                                subtitle:
                                    'Items available',
                                icon:
                                    Icons.check_circle_outline,
                                iconBackground:
                                    const Color(0xFFE8F8EF),
                                onTap: () {
                                  _showMessage(
                                    context,
                                    'Available Stock: 1,120',
                                  );
                                },
                              ),
                            ),

                            const SizedBox(width: 14),

                            Expanded(
                              child: _statCard(
                                title: 'Low Stock',
                                value: '85',
                                subtitle:
                                    'Items need attention',
                                icon:
                                    Icons.warning_amber_outlined,
                                iconBackground:
                                    const Color(0xFFFFF1E4),
                                onTap: () {
                                  _showMessage(
                                    context,
                                    'Low Stock Items: 85',
                                  );
                                },
                              ),
                            ),

                            const SizedBox(width: 14),

                            Expanded(
                              child: _statCard(
                                title: 'Out of Stock',
                                value: '45',
                                subtitle:
                                    'Items unavailable',
                                icon:
                                    Icons.remove_circle_outline,
                                iconBackground:
                                    const Color(0xFFFFEAEA),
                                onTap: () {
                                  _showMessage(
                                    context,
                                    'Out of Stock Items: 45',
                                  );
                                },
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 20),

                        // =================================================
                        // FILTER PANEL
                        // =================================================

                        _panel(
                          title: 'Inventory Filters',
                          child: Column(
                            children: [

                              const SizedBox(height: 14),

                              Row(
                                children: [

                                  Expanded(
                                    child: _filterField(
                                      context,
                                      'Warehouse',
                                      Icons
                                          .warehouse_outlined,
                                    ),
                                  ),

                                  const SizedBox(width: 12),

                                  Expanded(
                                    child: _filterField(
                                      context,
                                      'Item Group',
                                      Icons.category_outlined,
                                    ),
                                  ),

                                  const SizedBox(width: 12),

                                  Expanded(
                                    child: _filterField(
                                      context,
                                      'Stock Status',
                                      Icons
                                          .inventory_outlined,
                                    ),
                                  ),

                                  const SizedBox(width: 12),

                                  Expanded(
                                    child: _filterField(
                                      context,
                                      'Storage Location',
                                      Icons.grid_view,
                                    ),
                                  ),

                                  const SizedBox(width: 12),

                                  SizedBox(
                                    height: 43,
                                    child:
                                        ElevatedButton.icon(
                                      onPressed: () {
                                        _showMessage(
                                          context,
                                          'Inventory filters applied.',
                                        );
                                      },
                                      icon: const Icon(
                                        Icons.search,
                                        size: 17,
                                      ),
                                      label: const Text(
                                        'Apply',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 20),

                        // =================================================
                        // INVENTORY STOCK TABLE
                        // =================================================

                        _panel(
                          title: 'Inventory Stock',
                          action: 'Export',
                          actionOnTap: () {
                            _showMessage(
                              context,
                              'Inventory export started.',
                            );
                          },
                          child: Column(
                            children: [

                              const SizedBox(height: 15),

                              Container(
                                padding:
                                    const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 12,
                                ),
                                decoration:
                                    const BoxDecoration(
                                  color: Color(0xFFF8FAFC),
                                  borderRadius:
                                      BorderRadius.vertical(
                                    top: Radius.circular(7),
                                  ),
                                ),
                                child: const Row(
                                  children: [

                                    Expanded(
                                      flex: 2,
                                      child: Text(
                                        'Item',
                                        style:
                                            _tableHeaderStyle,
                                      ),
                                    ),

                                    Expanded(
                                      child: Text(
                                        'Warehouse',
                                        style:
                                            _tableHeaderStyle,
                                      ),
                                    ),

                                    Expanded(
                                      child: Text(
                                        'Location',
                                        style:
                                            _tableHeaderStyle,
                                      ),
                                    ),

                                    Expanded(
                                      child: Text(
                                        'Quantity',
                                        style:
                                            _tableHeaderStyle,
                                      ),
                                    ),

                                    Expanded(
                                      child: Text(
                                        'Status',
                                        style:
                                            _tableHeaderStyle,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              _stockRow(
                                context,
                                'RM-001',
                                'Raw Material',
                                'WH-01',
                                'Rack A / Bin 01',
                                '500',
                                'Available',
                              ),

                              _stockRow(
                                context,
                                'FG-001',
                                'Finished Goods',
                                'WH-01',
                                'Rack B / Bin 04',
                                '320',
                                'Available',
                              ),

                              _stockRow(
                                context,
                                'PK-001',
                                'Packaging',
                                'WH-02',
                                'Rack C / Bin 08',
                                '180',
                                'Low Stock',
                              ),

                              _stockRow(
                                context,
                                'CM-001',
                                'Consumables',
                                'WH-02',
                                'Rack D / Bin 03',
                                '100',
                                'Available',
                              ),

                              _stockRow(
                                context,
                                'RM-005',
                                'Raw Material',
                                'WH-01',
                                'Rack A / Bin 06',
                                '0',
                                'Out of Stock',
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SIDEBAR MENU
  // ============================================================

  Widget _menuItem(
    IconData icon,
    String title,
    bool selected,
    BuildContext context,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 5),
      decoration: BoxDecoration(
        color: selected
            ? const Color(0xFF3B82F6)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
      ),
      child: ListTile(
        dense: true,
        leading: Icon(
          icon,
          color: Colors.white,
          size: 20,
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
          ),
        ),
        onTap: () {
          _navigateToModule(
            context,
            title,
          );
        },
      ),
    );
  }

  // ============================================================
  // STAT CARD
  // ============================================================

  Widget _statCard({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color iconBackground,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: onTap,
      child: Container(
        height: 145,
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius:
              BorderRadius.circular(10),
          border: Border.all(
            color: const Color(0xFFE5E7EB),
          ),
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [

            Row(
              children: [

                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: iconBackground,
                    borderRadius:
                        BorderRadius.circular(9),
                  ),
                  child: Icon(
                    icon,
                    color:
                        const Color(0xFF2563EB),
                    size: 21,
                  ),
                ),

                const Spacer(),

                const Icon(
                  Icons.more_horiz,
                  color: Colors.grey,
                  size: 19,
                ),
              ],
            ),

            const SizedBox(height: 9),

            Text(
              title,
              style: const TextStyle(
                fontSize: 11,
                color: Color(0xFF6B7280),
              ),
            ),

            const SizedBox(height: 3),

            Text(
              value,
              style: const TextStyle(
                fontSize: 23,
                height: 1.1,
                fontWeight: FontWeight.bold,
                color: Color(0xFF111827),
              ),
            ),

            const SizedBox(height: 3),

            Text(
              subtitle,
              style: const TextStyle(
                fontSize: 10,
                color: Color(0xFF9CA3AF),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // FILTER FIELD
  // ============================================================

  Widget _filterField(
    BuildContext context,
    String title,
    IconData icon,
  ) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: () {
        _showMessage(
          context,
          '$title filter selected.',
        );
      },
      child: Container(
        height: 43,
        padding: const EdgeInsets.symmetric(
          horizontal: 12,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          borderRadius:
              BorderRadius.circular(8),
          border: Border.all(
            color: const Color(0xFFE5E7EB),
          ),
        ),
        child: Row(
          children: [

            Icon(
              icon,
              size: 17,
              color: const Color(0xFF6B7280),
            ),

            const SizedBox(width: 8),

            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF6B7280),
                ),
              ),
            ),

            const Icon(
              Icons.keyboard_arrow_down,
              size: 17,
              color: Color(0xFF6B7280),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // STOCK ROW
  // ============================================================

  Widget _stockRow(
    BuildContext context,
    String itemCode,
    String itemGroup,
    String warehouse,
    String location,
    String quantity,
    String status,
  ) {
    return InkWell(
      onTap: () {
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text(itemCode),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [

                  Text(
                    'Item Group: $itemGroup',
                  ),

                  const SizedBox(height: 8),

                  Text(
                    'Warehouse: $warehouse',
                  ),

                  const SizedBox(height: 8),

                  Text(
                    'Location: $location',
                  ),

                  const SizedBox(height: 8),

                  Text(
                    'Quantity: $quantity',
                  ),

                  const SizedBox(height: 8),

                  Text(
                    'Status: $status',
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Close'),
                ),
              ],
            );
          },
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 14,
        ),
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(
              color: Color(0xFFF0F0F0),
            ),
          ),
        ),
        child: Row(
          children: [

            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [

                  Text(
                    itemCode,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF111827),
                    ),
                  ),

                  const SizedBox(height: 3),

                  Text(
                    itemGroup,
                    style: const TextStyle(
                      fontSize: 9,
                      color: Color(0xFF6B7280),
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: Text(
                warehouse,
                style: const TextStyle(
                  fontSize: 10,
                ),
              ),
            ),

            Expanded(
              child: Text(
                location,
                style: const TextStyle(
                  fontSize: 9,
                  color: Color(0xFF6B7280),
                ),
              ),
            ),

            Expanded(
              child: Text(
                quantity,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Expanded(
              child: _statusBadge(status),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // STATUS BADGE
  // ============================================================

  Widget _statusBadge(String status) {
    Color color;

    if (status == 'Available') {
      color = Colors.green;
    } else if (status == 'Low Stock') {
      color = Colors.orange;
    } else {
      color = Colors.red;
    }

    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 8,
          vertical: 4,
        ),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius:
              BorderRadius.circular(10),
        ),
        child: Text(
          status,
          style: TextStyle(
            color: color,
            fontSize: 8,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  // ============================================================
  // COMMON PANEL
  // ============================================================

  Widget _panel({
    required String title,
    required Widget child,
    String? action,
    VoidCallback? actionOnTap,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(10),
        border: Border.all(
          color: const Color(0xFFE5E7EB),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [

          Row(
            children: [

              Text(
                title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF111827),
                ),
              ),

              const Spacer(),

              if (action != null)
                InkWell(
                  onTap: actionOnTap,
                  child: Text(
                    action,
                    style: const TextStyle(
                      color: Color(0xFF2563EB),
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 3),

          child,
        ],
      ),
    );
  }

  // ============================================================
  // MESSAGE
  // ============================================================

  void _showMessage(
    BuildContext context,
    String message,
  ) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// ============================================================
// TABLE HEADER STYLE
// ============================================================

const TextStyle _tableHeaderStyle = TextStyle(
  fontSize: 10,
  fontWeight: FontWeight.w600,
  color: Color(0xFF6B7280),
);